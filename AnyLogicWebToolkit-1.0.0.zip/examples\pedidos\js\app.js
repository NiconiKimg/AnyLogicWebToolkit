'use strict';

// ─── Mapa ────────────────────────────────────────────────────────────────────

const map = L.map('map').setView([-34.6037, -58.3816], 13);

L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
  attribution: '© CARTO',
  maxZoom: 19
}).addTo(map);

// Marcador de origen (deposito) que será actualizado por AnyLogic
const iconDeposito = L.divIcon({ className: '', html: '<div style="background:#0ea5e9;width:14px;height:14px;border-radius:50%;border:3px solid white;box-shadow:0 0 8px #0ea5e9"></div>', iconSize: [14, 14] });
const markerDeposito = L.marker([-34.6037, -58.3816], { icon: iconDeposito })
  .addTo(map)
  .bindTooltip('Depósito Central (Esperando a AnyLogic...)');

AnyLogic.events.on('setDeposito', (coords) => {
  const { lat, lng } = coords;
  markerDeposito.setLatLng([lat, lng]).bindTooltip('Depósito (AnyLogic)');
  map.setView([lat, lng], 13);
  document.getElementById('inputOrigen').value = `${lat.toFixed(5)}, ${lng.toFixed(5)} (Depósito)`;
});

// Marcador de destino seleccionado
let markerDestino = null;
let coordDestino  = null;

map.on('click', (e) => {
  coordDestino = e.latlng;
  if (markerDestino) markerDestino.setLatLng(e.latlng);
  else markerDestino = L.marker(e.latlng).addTo(map);
  document.getElementById('inputDestino').value = `${e.latlng.lat.toFixed(5)}, ${e.latlng.lng.toFixed(5)}`;
  document.getElementById('mapHint').classList.add('hidden');
});

document.getElementById('inputOrigen').value = '-34.60370, -58.38160 (Depósito)';

// ─── Vehiculos en tiempo real (marcadores de simulacion) ─────────────────────

const vehiculos = {};

AnyLogic.events.on('vehicleMoved', (data) => {
  const { id, lat, lng, label } = data;
  const latlng = [lat, lng];
  if (vehiculos[id]) {
    vehiculos[id].setLatLng(latlng);
  } else {
    const icon = L.divIcon({ className: '', html: `<div style="background:#f59e0b;width:14px;height:14px;border-radius:50%;border:2px solid white"></div>`, iconSize: [14, 14] });
    vehiculos[id] = L.marker(latlng, { icon }).addTo(map).bindTooltip(label || ('Camión ' + id));
  }
});

AnyLogic.events.on('pedidoCompletado', (pedidoId) => {
  // Marcar el pedido como completado visualmente y borrar el camión del mapa
  if (vehiculos[pedidoId]) {
    map.removeLayer(vehiculos[pedidoId]);
    delete vehiculos[pedidoId];
  }
  const idx = listaPedidos.findIndex(p => p.id === pedidoId);
  if (idx >= 0) {
    listaPedidos[idx].prioridad = 'COMPLETADO';
    renderLista();
  }
});

// ─── Gestion de pedidos ───────────────────────────────────────────────────────

const listaPedidos = [];

const pedidos = {
  async crearPedido() {
    if (!coordDestino) { alert('Selecciona un destino en el mapa'); return; }

    const pedido = {
      destino:    document.getElementById('inputDestino').value,
      descripcion:document.getElementById('inputDesc').value || 'Sin descripcion',
      prioridad:  document.getElementById('inputPrioridad').value,
      lat: coordDestino.lat,
      lng: coordDestino.lng,
      timestamp: new Date().toISOString()
    };

      pedido.id = 'PED-' + Math.floor(Math.random() * 10000);
      
      try {
        await AnyLogic.call('crearPedido', pedido);
        listaPedidos.push(pedido);
        renderLista();
        pedidos.limpiarFormulario();
      } catch (e) {
        console.error('Error creando pedido:', e);
        alert('Error: ' + (e.message || JSON.stringify(e)));
      }
  },

  eliminar(id) {
    const idx = listaPedidos.findIndex(p => p.id === id);
    if (idx >= 0) listaPedidos.splice(idx, 1);
    renderLista();
    // Notificar a AnyLogic
    AnyLogic.call('eliminarPedido', id).catch(console.error);
  },

  limpiarFormulario() {
    document.getElementById('inputDestino').value = '';
    document.getElementById('inputDesc').value    = '';
    document.getElementById('inputPrioridad').value = 'normal';
    if (markerDestino) { markerDestino.remove(); markerDestino = null; }
    coordDestino = null;
    document.getElementById('mapHint').classList.remove('hidden');
  }
};

function renderLista() {
  const container = document.getElementById('listaPedidos');
  document.getElementById('pedidosCount').textContent = `(${listaPedidos.length})`;
  container.innerHTML = '';

  if (listaPedidos.length === 0) {
    container.innerHTML = '<p style="color:var(--muted);font-size:.8rem;text-align:center;padding:16px">Sin pedidos</p>';
    return;
  }

  listaPedidos.forEach(p => {
    const el = document.createElement('div');
    el.className = 'pedido-item';
    el.innerHTML = `
      <div class="pedido-info">
        <div class="pedido-id">${p.id || 'Pendiente'}</div>
        <div class="pedido-dest">${p.destino}</div>
        <div class="pedido-desc">${p.descripcion}</div>
      </div>
      <span class="pedido-badge badge-${p.prioridad}">${p.prioridad}</span>
      <button class="btn-delete" title="Eliminar">✕</button>
    `;
    el.querySelector('.btn-delete').onclick = () => pedidos.eliminar(p.id);
    container.appendChild(el);
  });
}

// ─── Excel ────────────────────────────────────────────────────────────────────

const excel = {
  async importar() {
    try {
      const path = await AnyLogic.files.openDialog("Importar Excel de Pedidos", "*.xlsx");
      if (!path) return;
      
      const base64 = await AnyLogic.files.read(path, true);
      const wb = XLSX.read(base64, { type: 'base64' });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws);
      
      rows.forEach(row => {
        listaPedidos.push({
          id: row.ID || row.id || ('IMP-' + Date.now()),
          destino: row.Destino || row.destino || '',
          descripcion: row.Descripcion || row.descripcion || '',
          prioridad: row.Prioridad || row.prioridad || 'normal',
          timestamp: row.Timestamp || row.timestamp || new Date().toISOString()
        });
      });
      renderLista();
      AnyLogic.call('importarPedidos', listaPedidos).catch(console.error);
    } catch(e) {
      console.error(e);
      alert("Error al importar el archivo Excel");
    }
  },

  async exportar() {
    const data = listaPedidos.map(p => ({
      ID: p.id, Destino: p.destino, Descripcion: p.descripcion,
      Prioridad: p.prioridad, Timestamp: p.timestamp
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Pedidos');
    
    // Convertir el Excel a Base64 usando SheetJS
    const base64 = XLSX.write(wb, { bookType: 'xlsx', type: 'base64' });
    
    try {
      const path = await AnyLogic.files.saveDialog("Guardar Excel", "pedidos_exportados.xlsx");
      if (path) {
        await AnyLogic.files.write(path, base64, true);
        alert("¡Excel guardado exitosamente en:\n" + path);
      }
    } catch(e) {
      console.error(e);
      alert("Error al guardar el archivo");
    }
  }
};

// ─── Init ─────────────────────────────────────────────────────────────────────

window.addEventListener('load', () => {
  renderLista();
  // Inicializar estado desde el modelo
  AnyLogic.call('obtenerPedidos').then(data => {
    if (Array.isArray(data)) { listaPedidos.push(...data); renderLista(); }
  }).catch(() => { /* modelo puede no tener este comando en la primera carga */ });
});
